package ml.extraction;

public interface ExtractID {
	
	public String extract(Object o);

}
