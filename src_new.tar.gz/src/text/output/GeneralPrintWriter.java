package text.output;

public interface GeneralPrintWriter {

	public void print(String s);
	public void println(String s);
	
}
